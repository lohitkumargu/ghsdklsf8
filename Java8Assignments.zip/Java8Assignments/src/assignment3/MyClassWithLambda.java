package assignment3;

public class MyClassWithLambda  {

	public static void main(String args[]){
		WordCount wc = (str)-> str.length();
		System.out.println(wc.count("Ram"));
	}

}
