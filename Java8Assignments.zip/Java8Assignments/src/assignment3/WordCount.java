package assignment3;

public interface WordCount {
	int count(String str);
}
