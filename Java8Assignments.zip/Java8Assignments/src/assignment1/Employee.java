package assignment1;
import java.util.ArrayList;

/**
 * 
 */

/**
 * @author GU386168
 *
 */
public class Employee {

	/**
	 * 
	 */
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	private int id;
	private String name;
	private String address;
	private double salary;
	/**
	 * @param id
	 * @param name
	 * @param address
	 * @param salary
	 */
	public Employee(int id, String name, String address, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}
	
	public void getDetails(Employee emp){
		System.out.println(emp.getName()+" salary is "+emp.getSalary()+" staying in "+emp.getAddress());
	}
	
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}

	/**
	 * @param salary the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}

	public static void main(String args[]){
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(1, "Ram", "Bangalore", 35000.00));
		empList.add(new Employee(2, "Abhi", "Chennai", 40000.00));
		empList.add(new Employee(3, "Kishan", "Hyderabad", 65000.00));
		empList.add(new Employee(4, "John", "Kochi", 75000.00));
		for (Employee employee : empList) {
			employee.getDetails(employee);
		}
		
	}
}
