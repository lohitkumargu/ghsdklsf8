package assignment2;

public class Instrument implements Piano,Guitar {

	

	@Override
	public void play() {
//		Guitar.super.play();
		Piano.super.play();
//		System.out.println("Inside Instrument class");
	}
	
	public static void main(String args[]){
		new Instrument().play();
		
	}

}
