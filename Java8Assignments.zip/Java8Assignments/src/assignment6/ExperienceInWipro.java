package assignment6;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ExperienceInWipro {

	public static void main(String... strings) {
		System.out.println("Enter Date(in DD-MM-YYYY):");
		Scanner scan = new Scanner(System.in);
		String date = scan.next();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MM-yyyy");
		LocalDate loc = LocalDate.parse(date, formatter);
		Period p = Period.between(loc,LocalDate.now());
		System.out.println("Experience is  " + 
		p.getYears()+" Years "+p.getMonths()+" months "+p.getDays()+" days ");
	}
}
