package assignment5;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

public class SecondSunday{

	public static void main(String... strings) {
		LocalDate currentDate = LocalDate.now();
		LocalDate secondSunday = LocalDate.of(currentDate.getYear(), currentDate.getMonth().plus(1), 1)
				.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))
				.with(TemporalAdjusters.next(DayOfWeek.SUNDAY));
		System.out.println("Second Sunday is on " + secondSunday);

	}
}