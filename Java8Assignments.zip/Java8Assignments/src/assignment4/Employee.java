package assignment4;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 * 
 */

/**
 * @author GU386168
 *
 */
public class Employee {

	/**
	 * 
	 */
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	private int id;
	private String name;
	private String address;
	private Double salary;

	/**
	 * @param id
	 * @param name
	 * @param address
	 * @param salary
	 */
	public Employee(int id, String name, String address, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}

	public void getDetails(Employee emp) {
		System.out.println(emp.getName() + " salary is " + emp.getSalary() + " staying in " + emp.getAddress());
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the salary
	 */
	public Double getSalary() {
		return salary;
	}

	/**
	 * @param salary
	 *            the salary to set
	 */
	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public static int compareBySal(Employee e1,Employee e2) {
		return e1.getSalary().compareTo(e2.getSalary());
	}

	public static void main(String args[]) {
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(1, "Ram", "Bangalore", 90000.00));
		empList.add(new Employee(2, "Abhi", "Chennai", 80000.00));
		empList.add(new Employee(3, "Kishan", "Hyderabad", 65000.00));
		empList.add(new Employee(4, "John", "Kochi", 75000.00));
		for (Employee employee : empList) {
			employee.getDetails(employee);
		}
		Collections.sort(empList,(e1,e2)->{return e1.getSalary().compareTo(e2.getSalary());});
		//Collections.sort(empList,Employee::compareBySal);
		System.out.println("---------------------");
		for (Employee employee : empList) {
			employee.getDetails(employee);
		}

	}
}
