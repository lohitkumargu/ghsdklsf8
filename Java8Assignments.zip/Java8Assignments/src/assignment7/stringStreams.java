package assignment7;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class stringStreams {

	public static void main(String args[]) {
		List<String> strList = new ArrayList<>();
		strList.add("Ram");
		strList.add("Ramesh");
		strList.add("Ramghu");
		strList.add("Raghu");
		strList.add("Rohan");
		strList.add(" ");
		strList.add("");
		strList.add("");
		strList.add("");
		strList.add("");
		strList.add(" ");
		Stream<String> strStream = strList.stream();
		System.out.print("Number of Empty String are :");
		List emptyList = strStream.filter(str -> str.length()==0).collect(Collectors.toList());
		System.out.println(emptyList.size());
		
		System.out.println("Strings having Length Greater Than 5: ");
		Stream<String> strStream1 = strList.stream();
		strStream1.filter(str -> str.length()>5).forEach(System.out::println);
	}

}
